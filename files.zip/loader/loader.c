#include "loader.h"  // Include necessary headers

Elf32_Ehdr *ehdr;    // ELF header pointer
Elf32_Phdr *phdr;    // Program header pointer
int fd;              // File descriptor for the ELF file
Elf32_Phdr* ptr_ptload = NULL;  // Pointer to the program header for PT_LOAD segments
void* virtual_mem;   // Pointer to the allocated virtual memory space

/*
 * Function to release memory and perform cleanup.
 */
void loader_cleanup() {
  if (phdr != NULL) {
    free(phdr);
    phdr = NULL;
  }

  if (ehdr != NULL) {
    free(ehdr);
    ehdr = NULL;
  }

  if (munmap(virtual_mem, ptr_ptload->p_memsz) == -1) {
    fprintf(stderr, "Error in unmapping");
    exit(1);
  }
}

/*
 * Load and run the ELF executable file.
 */
void load_and_run_elf(char** exe) {
  fd = open(exe[1], O_RDONLY);

  if (fd < 0) {
    fprintf(stderr, "Error in opening the file");
    exit(1);
  }

  // Allocate memory for the ELF header
  ehdr = (Elf32_Ehdr*)malloc(sizeof(Elf32_Ehdr));

  if (ehdr == NULL) {
    fprintf(stderr, "Memory allocation failed");
    exit(1);
  }

  // Read the ELF header from the file
  int d = read(fd, ehdr, sizeof(Elf32_Ehdr));

  if (d != sizeof(Elf32_Ehdr)) {
    fprintf(stderr, "Error in reading the file");
    exit(1);
  }

  // Seek to the program header table
  int e = lseek(fd, ehdr->e_phoff, SEEK_SET);

  if (e < 0) {
    fprintf(stderr, "Error in lseek");
    exit(1);
  }

  // Allocate memory for the program header table
  phdr = (Elf32_Phdr*)malloc(ehdr->e_phentsize * ehdr->e_phnum);

  if (phdr == NULL) {
    fprintf(stderr, "Memory allocation failed");
    exit(1);
  }

  // Read the program header table from the file
  int f = read(fd, phdr, ehdr->e_phentsize * ehdr->e_phnum);

  if (f != ehdr->e_phentsize * ehdr->e_phnum) {
    fprintf(stderr, "Error in read");
    exit(1);
  }

  // Find the PT_LOAD segment containing the entry point
  for (int i = 0; i < ehdr->e_phnum; i++) {
    Elf32_Phdr* temp = phdr + i;
    if (temp->p_type == PT_LOAD) {
      if (temp->p_vaddr <= ehdr->e_entry && ehdr->e_entry < temp->p_vaddr + temp->p_memsz) {
        ptr_ptload = temp;
        break;
      }
    }
  }

  // Map the virtual memory and load the segment content
  virtual_mem = mmap((void*)ptr_ptload->p_vaddr, ptr_ptload->p_memsz, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_FIXED | MAP_PRIVATE, fd, ptr_ptload->p_offset);
  if (virtual_mem== MAP_FAILED) {
    fprintf(stderr,"Error in mmap");
    exit(1);
  }
  // Typecast the entry point address to a function pointer
  int (*_start)(void) = (int(*)(void))(ehdr->e_entry);

  // Call the entry point function
  int result = _start();

  // Print the result
  printf("User _start return value = %d\n", result);
}